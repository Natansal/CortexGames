let btnsGame = document.getElementsByClassName("btnGame");
let isSignIn = true;
btnsGame[0].addEventListener("click", function(){
    if (isSignIn == false) {return;}
    location.href = "../landing/index.html";
});
btnsGame[1].addEventListener("click", function () {
    if (isSignIn === false) { return; }
    location.reload();
});