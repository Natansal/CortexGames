const board = document.getElementById("board");
// let history = [];
// function addHistory(type, color, ){

// }
const peices = {
    bishop: { true: "chessPecies/bishop-w.svg", false: "chessPecies/bishop-b.svg" },
    king: { true: "chessPecies/king-w.svg", false: "chessPecies/king-b.svg" },
    knight: { true: "chessPecies/knight-w.svg", false: "chessPecies/knight-b.svg" },
    pawn: { true: "chessPecies/pawn-w.svg", false: "chessPecies/pawn-b.svg" },
    queen: { true: "chessPecies/queen-w.svg", false: "chessPecies/queen-b.svg" },
    rook: { true: "chessPecies/rook-w.svg", false: "chessPecies/rook-b.svg" }
};
let gameArr = [];
function tileObjFactory(i, j, contain, tile, color, type) {
    let obj = {};
    obj.i = i;
    obj.j = j;
    obj.contain = contain;
    obj.color = color;
    obj.type = type;
    obj.tile = tile;
    obj.moved = false;
    return obj;
}
for (let i = 0; i < 8; i++) {
    gameArr[i] = [];
    for (let j = 0; j < 8; j++) {
        let div = document.createElement("div");
        div.className = "tile";
        if (j % 2 - i % 2 == 0) {
            div.classList.add("grey");
        }
        else {
            div.classList.add("white");
        }
        board.appendChild(div);
        gameArr[i][j] = tileObjFactory(i, j, false, div);
    }
}
const tiles = board.querySelectorAll(".tile");
resetBoard();
function resetBoard() {//set start position
    setPeice(0, 0, "rook", true, false);
    setPeice(0, 1, "knight", true, false);
    setPeice(0, 2, "bishop", true, false);
    setPeice(0, 3, "queen", true, false);
    setPeice(0, 4, "king", true, false);
    setPeice(0, 5, "bishop", true, false);
    setPeice(0, 6, "knight", true, false);
    setPeice(0, 7, "rook", true, false);
    setPeice(7, 0, "rook", false, false);
    setPeice(7, 1, "knight", false, false);
    setPeice(7, 2, "bishop", false, false);
    setPeice(7, 3, "queen", false, false);
    setPeice(7, 4, "king", false, false);
    setPeice(7, 5, "bishop", false, false);
    setPeice(7, 6, "knight", false, false);
    setPeice(7, 7, "rook", false, false);
    for (let i = 0; i < 8; i++) {
        setPeice(1, i, "pawn", true, false);
        setPeice(6, i, "pawn", false, false);
    }
}
function setPeice(i, j, type, color, moved) {
    gameArr[i][j].color = color;
    gameArr[i][j].type = type;
    gameArr[i][j].contain = true;
    gameArr[i][j].moved = moved;
    gameArr[i][j].tile.style.backgroundImage = "url(" + peices[type][color] + ")";
}
function removePeice(i, j) {
    let m = 8 * i + j;
    gameArr[i][j] = tileObjFactory(i, j, false, tiles[m], false, false);
    tiles[m].style.backgroundImage = "";
}
function movePiece(iStart, jStart, iEnd, jEnd) {
    setPeice(iEnd, jEnd, gameArr[iStart][jStart].type, gameArr[iStart][jStart].color, gameArr[iStart][jStart].moved);
    removePeice(iStart, jStart);
}