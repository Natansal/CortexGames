let turn = true;//true=white turn; false=black turn
clickCounter = 0;//if(0){needs to click a peice to move} if(1){needs to click a place to move to}
let selected = {};
board.addEventListener("click", firstTileClick);
board.addEventListener("click", secondTileClick);
function firstTileClick(e) {
    let target = e.target;
    if (target === board || clickCounter != 0) {
        return;
    }
    let index;
    for (let i = 0; i < tiles.length; i++) {
        if (tiles[i] === target) {
            index = i;
            break;
        }
    }
    let i = parseInt(index / 8);
    let j = index % 8;
    if (gameArr[i][j].contain == false || gameArr[i][j].color != turn) {
        return;
    }
    gameArr[i][j].tile.classList.add("turquoise");
    colorCorrectTiles(i, j, true);
    clickCounter++;
    selected.i = i;
    selected.j = j;
}
function secondTileClick(e) {
    let target = e.target;
    if (target === board || clickCounter == 0) {
        return;
    }
    let index;
    for (let i = 0; i < tiles.length; i++) {
        if (tiles[i] === target) {
            index = i;
            break;
        }
    }
    let i = parseInt(index / 8);
    let j = index % 8;
    if (gameArr[i][j].contain == true && gameArr[i][j].color == turn) {
        unColorBoard();
        clickCounter = 0;
        firstTileClick(e);
        return;
    }
    if (!target.classList.contains("violet")) {
        return;
    }
    if (gameArr[selected.i][selected.j].type == "king" && j == selected.j - 2) {
        movePiece(selected.i, 0, selected.i, selected.j - 1);
        gameArr[selected.i][selected.j - 1].moved = true;
    }
    if (gameArr[selected.i][selected.j].type == "king" && j == selected.j + 2) {
        movePiece(selected.i, 7, selected.i, selected.j + 1);
        gameArr[selected.i][selected.j - 1].moved = true;
    }
    movePiece(selected.i, selected.j, i, j);
    gameArr[i][j].moved = true;
    if(i==7 && gameArr[i][j].color && gameArr[i][j].type == "pawn"){
        gameArr[i][j].type = "queen";
        gameArr[i][j].tile.style.backgroundImage = "url(" + peices["queen"][true] + ")";
    }
    if(i==0 && !gameArr[i][j].color && gameArr[i][j].type == "pawn"){
        gameArr[i][j].type = "queen";
        gameArr[i][j].tile.style.backgroundImage = "url(" + peices["queen"][false] + ")";
    }
    unColorBoard();
    let check = isCheckMate();
    if (check == true) {//checkMate!
        let isturn;
        if (turn) {
            isturn = "White";
        } else {
            isturn = "Black";
        }
        board.innerHTML = "Well done!!!!\n" + isturn + " wins!!!";
    }
    else if (check == "draw") {//Draw....
        console.log("draw...");
    }
    turn = !turn;
    clickCounter = 0;
}
function unColorBoard() {
    for (let i = 0; i < 8; i++) {
        for (let j = 0; j < 8; j++) {
            if (gameArr[i][j].tile.classList.contains("violet")) {
                gameArr[i][j].tile.classList.remove("violet");
            }
            if (gameArr[i][j].tile.classList.contains("turquoise")) {
                gameArr[i][j].tile.classList.remove("turquoise");
            }
        }
    }
}
function colorCorrectTiles(i, j, checkMove) {
    let moves = allAllowedMoves(i, j);
    for (let k = 0; k < 8; k++) {
        for (let l = 0; l < 8; l++) {
            if (moves[k][l] == true && !isCheck(i, j, k, l, gameArr[i][j].color, true)) {
                gameArr[k][l].tile.classList.add("violet");
            }
        }
    }
    //Success הצרחה
    if (checkMove) {
        let whoToSuccess;
        let IsGood = true;
        if (turn) {
            whoToSuccess = 0;
        }
        else {
            whoToSuccess = 7;
        }
        if (gameArr[i][j].type == "king" && !gameArr[i][j].moved && gameArr[whoToSuccess][0].contain && !gameArr[whoToSuccess][0].moved) {
            if (isCheck(0, 0, 0, 0, gameArr[i][j].color, false) || isCheck(whoToSuccess, j, whoToSuccess, 0, gameArr[i][j].color, true)) {
                IsGood = false;
            }
            for (let m = 1; m < j; m++) {
                if (gameArr[whoToSuccess][m].contain || isCheck(i, j, whoToSuccess, m, gameArr[i][j].color, true)) {
                    IsGood = false;
                    break;
                }
            }
            if (IsGood) {
                gameArr[whoToSuccess][j - 2].tile.classList.add("violet");
            }
        }
        IsGood = true;
        if (gameArr[i][j].type == "king" && !gameArr[i][j].moved && gameArr[whoToSuccess][7].contain && !gameArr[whoToSuccess][7].moved) {
            if (isCheck(0, 0, 0, 0, gameArr[i][j].color, false) || isCheck(whoToSuccess, j, whoToSuccess, 7, gameArr[i][j].color, true)) {
                IsGood = false;
            }
            for (let m = 6; m > j; m--) {
                if (gameArr[whoToSuccess][m].contain || isCheck(i, j, whoToSuccess, m, gameArr[i][j].color, true)) {
                    IsGood = false;
                    break;
                }
            }
            if (IsGood) {
                gameArr[whoToSuccess][j + 2].tile.classList.add("violet");
            }
        }
    }
}
function allAllowedMoves(i, j) {
    let arr = [];
    for (let i1 = 0; i1 < 8; i1++) {
        arr[i1] = [];
        for (let j1 = 0; j1 < 8; j1++) {
            arr[i1][j1] = false;
        }
    }
    let target = gameArr[i][j];
    if (target.color) {//if pawn
        if (target.type == "pawn") {
            if (i == 1 && gameArr[i + 1][j].contain == false && gameArr[i + 2][j].contain == false) {
                arr[i + 2][j] = true;
            }
            if (i < 7 && gameArr[i + 1][j].contain == false) {
                arr[i + 1][j] = true;
            }
            if (j < 7 && i < 7 && gameArr[i + 1][j + 1].contain && gameArr[i + 1][j + 1].color === !target.color) {
                arr[i + 1][j + 1] = true;
            }
            if (j > 0 && i < 7 && gameArr[i + 1][j - 1].contain && gameArr[i + 1][j - 1].color === !target.color) {
                arr[i + 1][j - 1] = true;
            }
        }
    }
    if (!target.color) {
        if (target.type == "pawn") {
            if (i == 6 && gameArr[i - 1][j].contain == false && gameArr[i - 2][j].contain == false) {
                arr[i - 2][j] = true;
            }
            if (i > 0 && gameArr[i - 1][j].contain == false) {
                arr[i - 1][j] = true;
            }
            if (j < 7 && i > 0 && gameArr[i - 1][j + 1].contain && gameArr[i - 1][j + 1].color === !target.color) {
                arr[i - 1][j + 1] = true;
            }
            if (j > 0 && i > 0 && gameArr[i - 1][j - 1].contain && gameArr[i - 1][j - 1].color === !target.color) {
                arr[i - 1][j - 1] = true;
            }
        }
    }
    if (target.type == "king") {//if king
        for (let k = i - 1; k <= i + 1; k++) {
            for (let l = j - 1; l <= j + 1; l++) {
                if (l >= 0 && l <= 7 && k >= 0 && k <= 7 && (k != i || l != j)) {
                    if (gameArr[k][l].contain == false || (gameArr[k][l].contain && gameArr[k][l].color != target.color)) {
                        arr[k][l] = true;
                    }
                }
            }
        }
    }
    if (target.type == "rook" || target.type == "queen") {//if rook or queen
        for (let k = i + 1; k < 8; k++) {//check down from tool
            if (!gameArr[k][j].contain) {
                arr[k][j] = true;
            } else if (gameArr[k][j].color != target.color) {
                arr[k][j] = true;
                break;
            } else {
                break;
            }
        }
        for (let k = i - 1; k >= 0; k--) {//check up from tool
            if (!gameArr[k][j].contain) {
                arr[k][j] = true;
            } else if (gameArr[k][j].color != target.color) {
                arr[k][j] = true;
                break;
            } else {
                break;
            }
        }
        for (let k = j + 1; k < 8; k++) {//check right from tool
            if (!gameArr[i][k].contain) {
                arr[i][k] = true;
            } else if (gameArr[i][k].color != target.color) {
                arr[i][k] = true;
                break;
            } else {
                break;
            }
        }
        for (let k = j - 1; k >= 0; k--) {//check left from tool
            if (!gameArr[i][k].contain) {
                arr[i][k] = true;
            } else if (gameArr[i][k].color != target.color) {
                arr[i][k] = true;
                break;
            } else {
                break;
            }
        }
    }
    if (target.type == "bishop" || target.type == "queen") {//if bishop or queen
        for (let k = 1; k < 8 - Math.max(i, j); k++) {//check down-right from tool +,+
            if (!gameArr[i + k][j + k].contain) {
                arr[i + k][j + k] = true;
            }
            else if (gameArr[i + k][j + k].color != target.color) {
                arr[i + k][j + k] = true;
                break;
            } else {
                break;
            }
        }
        for (let k = 1; k < 8 - Math.max(i, 7 - j); k++) {//check down-left +,-
            if (!gameArr[i + k][j - k].contain) {
                arr[i + k][j - k] = true;
            }
            else if (gameArr[i + k][j - k].color != target.color) {
                arr[i + k][j - k] = true;
                break;
            } else {
                break;
            }
        }
        for (let k = 1; k < 8 - Math.max(7 - i, j); k++) {//check up-right -,+
            if (!gameArr[i - k][j + k].contain) {
                arr[i - k][j + k] = true;
            }
            else if (gameArr[i - k][j + k].color != target.color) {
                arr[i - k][j + k] = true;
                break;
            } else {
                break;
            }
        }
        for (let k = 1; k < 8 - Math.max(7 - i, 7 - j); k++) {//check up-left -,-
            if (!gameArr[i - k][j - k].contain) {
                arr[i - k][j - k] = true;
            }
            else if (gameArr[i - k][j - k].color != target.color) {
                arr[i - k][j - k] = true;
                break;
            } else {
                break;
            }
        }
    }
    if (target.type == "knight") {
        if (i < 7 && j < 6 && (!gameArr[i + 1][j + 2].contain || (gameArr[i + 1][j + 2].contain && gameArr[i + 1][j + 2].color != target.color))) {
            arr[i + 1][j + 2] = true;//+1,+2
        }
        if (i < 6 && j < 7 && (!gameArr[i + 2][j + 1].contain || (gameArr[i + 2][j + 1].contain && gameArr[i + 2][j + 1].color != target.color))) {
            arr[i + 2][j + 1] = true;//+2,+1
        }
        if (i > 1 && j < 7 && (!gameArr[i - 2][j + 1].contain || (gameArr[i - 2][j + 1].contain && gameArr[i - 2][j + 1].color != target.color))) {
            arr[i - 2][j + 1] = true;//-2,+1
        }
        if (i > 0 && j < 6 && (!gameArr[i - 1][j + 2].contain || (gameArr[i - 1][j + 2].contain && gameArr[i - 1][j + 2].color != target.color))) {
            arr[i - 1][j + 2] = true;//-1,+2
        }
        if (i < 7 && j > 1 && (!gameArr[i + 1][j - 2].contain || (gameArr[i + 1][j - 2].contain && gameArr[i + 1][j - 2].color != target.color))) {
            arr[i + 1][j - 2] = true;//+1,-2
        }
        if (i < 6 && j > 0 && (!gameArr[i + 2][j - 1].contain || (gameArr[i + 2][j - 1].contain && gameArr[i + 2][j - 1].color != target.color))) {
            arr[i + 2][j - 1] = true;//+2,-1
        }
        if (i > 0 && j > 1 && (!gameArr[i - 1][j - 2].contain || (gameArr[i - 1][j - 2].contain && gameArr[i - 1][j - 2].color != target.color))) {
            arr[i - 1][j - 2] = true;//-1,-2
        }
        if (i > 1 && j > 0 && (!gameArr[i - 2][j - 1].contain || (gameArr[i - 2][j - 1].contain && gameArr[i - 2][j - 1].color != target.color))) {
            arr[i - 2][j - 1] = true;//-2,-1
        }
    }
    return arr;
}
function isCheck(iStart, jStart, iEnd, jEnd, color, shouldMove) {
    let wasDelete = false;
    if (gameArr[iEnd][jEnd].contain) {
        wasDelete = true;
    }
    let deleted;
    if (shouldMove) {
        deleted = { i: iEnd, j: jEnd, color: gameArr[iEnd][jEnd].color, type: gameArr[iEnd][jEnd].type, contain: gameArr[iEnd][jEnd].contain, moved: gameArr[iEnd][jEnd].moved };
        movePiece(iStart, jStart, iEnd, jEnd);
    }
    let iKing, jking;
    for (let i = 0; i < 8; i++) {//find king position
        for (let j = 0; j < 8; j++) {
            if (gameArr[i][j].type == "king" && gameArr[i][j].color == color) {
                iKing = i;
                jking = j;
                break;
            }
        }
    }

    for (let i = 0; i < 8; i++) {
        for (let j = 0; j < 8; j++) {
            let enemy = gameArr[i][j];
            if (enemy.contain && enemy.color != color) {
                let arr = allAllowedMoves(i, j);
                if (arr[iKing][jking]) {
                    if (shouldMove) {
                        movePiece(iEnd, jEnd, iStart, jStart);
                        if (wasDelete) {
                            setPeice(deleted.i, deleted.j, deleted.type, deleted.color, deleted.moved);
                        }
                    }
                    return true;
                }
            }
        }
    }
    if (shouldMove) {
        movePiece(iEnd, jEnd, iStart, jStart);
        if (wasDelete) {
            setPeice(deleted.i, deleted.j, deleted.type, deleted.color, deleted.moved);
        }
    }
    return false;
}
function isCheckMate() {
    if (isCheck(0, 0, 0, 0, !turn, false)) {
        if (canAnyMove(!turn) == false) {
            return true;
        }
    } else {
        if (canAnyMove(!turn) == false) {
            return "draw";
        }
    }
    return false;
}
function canAnyMove(color) {
    for (let i = 0; i < 8; i++) {
        for (let j = 0; j < 8; j++) {
            let tool = gameArr[i][j];
            if (tool.contain && tool.color == color) {
                colorCorrectTiles(i, j, false);
            }
        }
    }
    for (let i = 0; i < 8; i++) {
        for (let j = 0; j < 8; j++) {
            if (gameArr[i][j].tile.classList.contains("violet")) {
                unColorBoard();
                return true;
            }
        }
    }
    unColorBoard();
    return false;
}